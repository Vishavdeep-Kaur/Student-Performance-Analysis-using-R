# Generate a reproducible, fictional student dataset for this project.
# No real student records are used.

find_project_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)))
  }
  frames <- sys.frames()
  source_files <- vapply(frames, function(frame) {
    if (!is.null(frame$ofile)) frame$ofile else ""
  }, character(1))
  source_files <- source_files[nzchar(source_files)]
  if (length(source_files)) return(dirname(normalizePath(tail(source_files, 1), mustWork = TRUE)))
  getwd()
}

set.seed(2026)
n <- 250
project_dir <- find_project_dir()
data_dir <- file.path(project_dir, "data")
dir.create(data_dir, showWarnings = FALSE, recursive = TRUE)

study_hours <- pmin(pmax(round(rnorm(n, mean = 7.5, sd = 3.0), 1), 1), 16)
attendance <- pmin(pmax(round(rnorm(n, mean = 84, sd = 9), 1), 50), 100)
previous_average <- pmin(pmax(round(rnorm(n, mean = 70, sd = 13), 1), 25), 98)
sleep_hours <- pmin(pmax(round(rnorm(n, mean = 7, sd = 0.9), 1), 4), 10)

assignment_average <- pmin(pmax(round(
  33 + 0.42 * previous_average + 0.35 * (attendance - 50) +
    0.60 * study_hours + rnorm(n, mean = 0, sd = 9), 1
), 0), 100)

final_exam_score <- pmin(pmax(round(
  16 + 0.25 * previous_average + 0.35 * assignment_average +
    0.14 * (attendance - 50) + 0.60 * study_hours +
    0.70 * (sleep_hours - 7) + rnorm(n, mean = 0, sd = 9), 1
), 0), 100)

students <- data.frame(
  Student_ID = sprintf("STU%03d", seq_len(n)),
  Study_Hours_Per_Week = study_hours,
  Attendance_Percent = attendance,
  Assignment_Average = assignment_average,
  Previous_Term_Average = previous_average,
  Sleep_Hours_Per_Night = sleep_hours,
  Final_Exam_Score = final_exam_score,
  stringsAsFactors = FALSE
)

output_file <- file.path(data_dir, "student_performance_synthetic.csv")
write.csv(students, output_file, row.names = FALSE)
cat("Created", nrow(students), "fictional student records at:\n", output_file, "\n")
