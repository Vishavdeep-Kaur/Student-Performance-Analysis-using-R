# Student Performance Analysis
# Reproducible synthetic data only; this project contains no real student records.
# Run this complete file with Source in RStudio. Uses base R; no packages needed.

find_project_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE)))
  }
  frames <- sys.frames()
  source_files <- vapply(frames, function(frame) {
    if (!is.null(frame$ofile)) frame$ofile else ""
  }, character(1))
  source_files <- source_files[nzchar(source_files)]
  if (length(source_files)) return(dirname(normalizePath(tail(source_files, 1), mustWork = TRUE)))
  getwd()
}

project_dir <- find_project_dir()
data_file <- file.path(project_dir, "data", "student_performance_synthetic.csv")
if (!file.exists(data_file)) source(file.path(project_dir, "create_student_performance_dataset.R"))
students <- read.csv(data_file, stringsAsFactors = FALSE)

required <- c(
  "Student_ID", "Study_Hours_Per_Week", "Attendance_Percent",
  "Assignment_Average", "Previous_Term_Average",
  "Sleep_Hours_Per_Night", "Final_Exam_Score"
)
missing_columns <- setdiff(required, names(students))
if (length(missing_columns)) stop("Missing columns: ", paste(missing_columns, collapse = ", "))
if (!nrow(students)) stop("The dataset has no records.")
if (anyNA(students[required])) stop("The dataset contains missing required values.")
if (anyDuplicated(students$Student_ID)) stop("Student_ID values must be unique.")

score_columns <- c("Assignment_Average", "Previous_Term_Average", "Final_Exam_Score")
if (any(as.matrix(students[score_columns]) < 0 | as.matrix(students[score_columns]) > 100)) {
  stop("Score columns must be between 0 and 100.")
}
if (any(students$Attendance_Percent < 0 | students$Attendance_Percent > 100)) {
  stop("Attendance_Percent must be between 0 and 100.")
}
if (any(students$Study_Hours_Per_Week < 0 | students$Sleep_Hours_Per_Night < 0)) {
  stop("Study and sleep hours cannot be negative.")
}

students$Study_Band <- cut(
  students$Study_Hours_Per_Week,
  breaks = c(-Inf, 4, 8, 12, Inf),
  labels = c("0-4 hours", "5-8 hours", "9-12 hours", ">12 hours")
)
students$Attendance_Band <- cut(
  students$Attendance_Percent,
  breaks = c(-Inf, 70, 85, 95, Inf), right = FALSE,
  labels = c("Below 70%", "70-84%", "85-94%", "95-100%")
)
students$Score_Band <- cut(
  students$Final_Exam_Score,
  breaks = c(-Inf, 50, 65, 80, Inf),
  labels = c("Below 50", "50-64", "65-79", "80+")
)
students$Below_50_Flag <- students$Final_Exam_Score < 50

numeric_fields <- c(
  "Study_Hours_Per_Week", "Attendance_Percent", "Assignment_Average",
  "Previous_Term_Average", "Sleep_Hours_Per_Night", "Final_Exam_Score"
)
correlations <- cor(students[numeric_fields])
correlation_table <- data.frame(
  Measure = rownames(correlations), correlations,
  check.names = FALSE, row.names = NULL
)

group_summary <- function(group_column) {
  result <- aggregate(
    students$Final_Exam_Score,
    by = list(Group = students[[group_column]]),
    FUN = function(x) c(Count = length(x), Mean = mean(x), SD = sd(x))
  )
  data.frame(
    Group = result$Group,
    Count = result$x[, "Count"],
    Mean_Final_Score = result$x[, "Mean"],
    SD_Final_Score = result$x[, "SD"]
  )
}
study_summary <- group_summary("Study_Band")
attendance_summary <- group_summary("Attendance_Band")
names(study_summary)[1] <- "Study_Band"
names(attendance_summary)[1] <- "Attendance_Band"

# Hold out one quarter for a simple demonstration model.
# The model does not use the final exam score as an input feature.
set.seed(42)
train_rows <- sample(seq_len(nrow(students)), size = floor(0.75 * nrow(students)))
train_data <- students[train_rows, ]
test_data <- students[-train_rows, ]
model <- lm(
  Final_Exam_Score ~ Study_Hours_Per_Week + Attendance_Percent +
    Assignment_Average + Previous_Term_Average + Sleep_Hours_Per_Night,
  data = train_data
)
test_data$Predicted_Score <- pmin(pmax(predict(model, newdata = test_data), 0), 100)
test_data$Prediction_Error <- test_data$Final_Exam_Score - test_data$Predicted_Score
rmse <- sqrt(mean(test_data$Prediction_Error^2))
mae <- mean(abs(test_data$Prediction_Error))
r_squared <- 1 - sum(test_data$Prediction_Error^2) /
  sum((test_data$Final_Exam_Score - mean(test_data$Final_Exam_Score))^2)
model_metrics <- data.frame(
  Metric = c("Training records", "Test records", "Test RMSE", "Test MAE", "Test R-squared"),
  Value = c(nrow(train_data), nrow(test_data), round(rmse, 2), round(mae, 2), round(r_squared, 3))
)
model_coefficients <- data.frame(
  Term = names(coef(model)), Estimate = as.numeric(coef(model)), row.names = NULL
)

feature_correlations <- correlations[setdiff(numeric_fields, "Final_Exam_Score"), "Final_Exam_Score"]
strongest_feature <- names(which.max(abs(feature_correlations)))
strongest_study_band <- study_summary$Study_Band[which.max(study_summary$Mean_Final_Score)]
strongest_attendance_band <- attendance_summary$Attendance_Band[which.max(attendance_summary$Mean_Final_Score)]
key_insights <- data.frame(
  Insight = c(
    "Synthetic records analyzed", "Average final exam score", "Median final exam score",
    "Records with score below 50", "Feature most associated with final score in this sample",
    "Study-time group with highest average score", "Attendance group with highest average score",
    "Held-out model RMSE"
  ),
  Result = c(
    nrow(students), sprintf("%.1f / 100", mean(students$Final_Exam_Score)),
    sprintf("%.1f / 100", median(students$Final_Exam_Score)), sum(students$Below_50_Flag),
    strongest_feature, as.character(strongest_study_band), as.character(strongest_attendance_band),
    sprintf("%.2f points", rmse)
  ),
  stringsAsFactors = FALSE
)

output_dir <- file.path(project_dir, "output")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
write.csv(students, file.path(output_dir, "student_results.csv"), row.names = FALSE)
write.csv(study_summary, file.path(output_dir, "study_group_summary.csv"), row.names = FALSE)
write.csv(attendance_summary, file.path(output_dir, "attendance_group_summary.csv"), row.names = FALSE)
write.csv(correlation_table, file.path(output_dir, "correlation_matrix.csv"), row.names = FALSE)
write.csv(model_metrics, file.path(output_dir, "model_metrics.csv"), row.names = FALSE)
write.csv(model_coefficients, file.path(output_dir, "model_coefficients.csv"), row.names = FALSE)
write.csv(test_data, file.path(output_dir, "held_out_predictions.csv"), row.names = FALSE)
write.csv(key_insights, file.path(output_dir, "key_insights.csv"), row.names = FALSE)

plot_width <- 1100
plot_height <- 750
palette <- c("#264653", "#2A9D8F", "#E9C46A", "#E76F51")
save_and_show <- function(file_name, draw_plot) {
  png(file.path(output_dir, file_name), width = plot_width, height = plot_height, res = 120)
  draw_plot()
  dev.off()
  if (interactive()) draw_plot()
}

draw_score_distribution <- function() {
  par(mar = c(5, 5, 4, 1), bg = "white")
  hist(
    students$Final_Exam_Score, breaks = seq(0, 100, by = 10),
    col = palette[2], border = "white", xlim = c(0, 100),
    xlab = "Final exam score (out of 100)", ylab = "Number of students",
    main = "Distribution of Final Exam Scores"
  )
  abline(v = mean(students$Final_Exam_Score), col = palette[4], lwd = 3, lty = 2)
  abline(v = 50, col = palette[1], lwd = 2, lty = 3)
  legend("topleft", legend = c("Class mean", "50-point reference"),
         col = c(palette[4], palette[1]), lty = c(2, 3), lwd = c(3, 2), bty = "n")
}

draw_study_boxplot <- function() {
  par(mar = c(6, 5, 4, 1), bg = "white")
  boxplot(
    Final_Exam_Score ~ Study_Band, data = students,
    col = palette, border = palette[1], ylim = c(0, 100),
    xlab = "Study hours per week", ylab = "Final exam score (out of 100)",
    main = "Score Spread Across Study-Time Groups"
  )
  grid(nx = NA, ny = NULL, col = "#DCE4E8", lty = 1)
  boxplot(Final_Exam_Score ~ Study_Band, data = students, add = TRUE,
          col = palette, border = palette[1], ylim = c(0, 100), axes = FALSE)
}

draw_attendance_scatter <- function() {
  par(mar = c(5, 5, 4, 1), bg = "white")
  plot(
    students$Attendance_Percent, students$Final_Exam_Score,
    pch = 21, bg = adjustcolor(palette[2], alpha.f = 0.65), col = "white", cex = 1.15,
    xlim = c(45, 102), ylim = c(0, 100),
    xlab = "Attendance (%)", ylab = "Final exam score (out of 100)",
    main = sprintf("Attendance and Final Score  |  r = %.2f",
                   cor(students$Attendance_Percent, students$Final_Exam_Score))
  )
  abline(lm(Final_Exam_Score ~ Attendance_Percent, data = students), col = palette[4], lwd = 3)
  grid(col = "#DCE4E8", lty = 1)
}

draw_assignment_scatter <- function() {
  par(mar = c(5, 5, 4, 1), bg = "white")
  plot(
    students$Assignment_Average, students$Final_Exam_Score,
    pch = 21, bg = adjustcolor(palette[3], alpha.f = 0.75), col = "white", cex = 1.15,
    xlim = c(0, 100), ylim = c(0, 100),
    xlab = "Assignment average (out of 100)", ylab = "Final exam score (out of 100)",
    main = sprintf("Assignment Work and Final Score  |  r = %.2f",
                   cor(students$Assignment_Average, students$Final_Exam_Score))
  )
  abline(lm(Final_Exam_Score ~ Assignment_Average, data = students), col = palette[4], lwd = 3)
  grid(col = "#DCE4E8", lty = 1)
}

draw_correlation_heatmap <- function() {
  par(mar = c(8, 8, 4, 2), bg = "white")
  corr <- correlations
  short_names <- c(
    Study_Hours_Per_Week = "Study hours",
    Attendance_Percent = "Attendance",
    Assignment_Average = "Assignments",
    Previous_Term_Average = "Prior term",
    Sleep_Hours_Per_Night = "Sleep",
    Final_Exam_Score = "Final exam"
  )
  rownames(corr) <- short_names[rownames(corr)]
  colnames(corr) <- short_names[colnames(corr)]
  heat_colors <- colorRampPalette(c("#457B9D", "#F7F7F2", "#E76F51"))(101)
  image(
    x = seq_len(ncol(corr)), y = seq_len(nrow(corr)), z = t(corr[nrow(corr):1, ]),
    col = heat_colors, zlim = c(-1, 1), axes = FALSE, xlab = "", ylab = "",
    main = "Correlation Between Numeric Variables"
  )
  axis(1, at = seq_len(ncol(corr)), labels = colnames(corr), las = 2, cex.axis = 0.8)
  axis(2, at = seq_len(nrow(corr)), labels = rev(rownames(corr)), las = 2, cex.axis = 0.8)
  for (i in seq_len(nrow(corr))) for (j in seq_len(ncol(corr))) {
    text(j, nrow(corr) - i + 1, labels = sprintf("%.2f", corr[i, j]), cex = 0.75)
  }
  box()
}

draw_prediction_plot <- function() {
  par(mar = c(5, 5, 4, 1), bg = "white")
  plot(
    test_data$Final_Exam_Score, test_data$Predicted_Score,
    pch = 21, bg = adjustcolor(palette[2], alpha.f = 0.75), col = "white", cex = 1.2,
    xlim = c(0, 100), ylim = c(0, 100),
    xlab = "Actual score", ylab = "Predicted score",
    main = sprintf("Held-Out Predictions  |  RMSE = %.1f, MAE = %.1f", rmse, mae)
  )
  abline(0, 1, col = palette[4], lwd = 3, lty = 2)
  grid(col = "#DCE4E8", lty = 1)
}

# Save a single six-page PDF as well as the individual PNG charts.
pdf(file.path(output_dir, "student_performance_charts.pdf"), width = 9, height = 6.5)
draw_score_distribution()
draw_study_boxplot()
draw_attendance_scatter()
draw_assignment_scatter()
draw_correlation_heatmap()
draw_prediction_plot()
dev.off()

save_and_show("01_score_distribution.png", draw_score_distribution)
save_and_show("02_study_time_groups.png", draw_study_boxplot)
save_and_show("03_attendance_vs_score.png", draw_attendance_scatter)
save_and_show("04_assignments_vs_score.png", draw_assignment_scatter)
save_and_show("05_correlation_heatmap.png", draw_correlation_heatmap)
save_and_show("06_actual_vs_predicted.png", draw_prediction_plot)

cat("Student Performance Analysis complete\n")
cat("Dataset: synthetic, fictional, and reproducible\n")
cat("Students analyzed:", nrow(students), "\n")
cat("Mean final score:", sprintf("%.1f / 100", mean(students$Final_Exam_Score)), "\n")
cat("Median final score:", sprintf("%.1f / 100", median(students$Final_Exam_Score)), "\n")
cat("Highest absolute correlation with final score:", strongest_feature, "\n")
cat("Test-set RMSE:", sprintf("%.2f points", rmse), "\n")
cat("Test-set MAE:", sprintf("%.2f points", mae), "\n")
cat("All charts and tables saved in:", output_dir, "\n")
cat("These simulated relationships are for practice and are not real-world findings.\n")
