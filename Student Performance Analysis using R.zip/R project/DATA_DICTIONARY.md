# Synthetic dataset notes

`data/student_performance_synthetic.csv` is generated locally by `create_student_performance_dataset.R` with a fixed random seed. It contains 250 fictional rows and no names or real student records.

The input features are generated independently or with mild simulated relationships. Assignment averages and final exam scores are then simulated from a documented formula that adds random variation. The analysis is therefore a demonstration of data preparation, visualization, correlation, and train/test evaluation—not a study of real student behavior.

The derived score-band cutoffs and the below-50 flag are illustrative project thresholds, not official academic standards.
